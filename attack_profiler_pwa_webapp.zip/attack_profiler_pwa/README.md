# ATT&CK Profiler PWA

Web app installabile su Android/iPhone. Backend e frontend sono serviti dalla stessa app FastAPI.

## Avvio locale

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Apri nel browser: http://localhost:8000

## Uso da smartphone

Devi pubblicarla online, ad esempio su Render, Railway, Fly.io o un VPS.
Dopo la pubblicazione apri l'URL dal telefono e scegli "Aggiungi alla schermata Home".

## Deploy rapido su Render

- Crea un nuovo Web Service
- Carica questo progetto su GitHub
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

## Nota

L'attribuzione dei gruppi è solo probabilistica e basata su compatibilità TTP. Non equivale a identificazione certa dell'autore.
