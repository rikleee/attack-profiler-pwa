from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Dict, List
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="ATT&CK Profiler PWA", version="0.2")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class AnalyzeRequest(BaseModel):
    description: str

TECHNIQUES: Dict[str, Dict] = {
    "T1566": {"name":"Phishing","tactic":"Initial Access","keywords":["phishing","email","mail","allegato","link malevolo","spearphishing"],"mitigations":["Email filtering","User awareness training","Sandbox allegati","SPF, DKIM e DMARC","Blocco link malevoli"]},
    "T1204": {"name":"User Execution","tactic":"Execution","keywords":["utente ha aperto","apertura","cliccato","eseguito","allegato","abilitato"],"mitigations":["Formazione utenti","Application control","EDR","Blocco esecuzione file sospetti"]},
    "T1059": {"name":"Command and Scripting Interpreter","tactic":"Execution","keywords":["macro","powershell","script","cmd","shell","vba"],"mitigations":["Limitare PowerShell","Bloccare macro non firmate","Monitorare script sospetti","Application allowlisting"]},
    "T1547.001": {"name":"Registry Run Keys / Startup Folder","tactic":"Persistence","keywords":["registro","registry","run key","startup","persistenza","runonce"],"mitigations":["Monitoraggio chiavi di registro","EDR","Least privilege","Controllo modifiche startup"]},
    "T1071": {"name":"Application Layer Protocol","tactic":"Command and Control","keywords":["c2","command and control","dominio esterno","http","https","dns","beacon"],"mitigations":["Proxy filtering","DNS monitoring","Network detection","Blocco domini sospetti"]},
    "T1021.001": {"name":"Remote Desktop Protocol","tactic":"Lateral Movement","keywords":["rdp","desktop remoto","accesso remoto"],"mitigations":["MFA su RDP","Limitare esposizione RDP","VPN obbligatoria","Monitorare login anomali"]},
    "T1562": {"name":"Impair Defenses","tactic":"Defense Evasion","keywords":["disattivato antivirus","disabilitato edr","impair defenses","tampering","disabilitato antivirus"],"mitigations":["Tamper protection","Hardening EDR","Alert su disattivazione antivirus","Privilege restriction"]},
    "T1486": {"name":"Data Encrypted for Impact","tactic":"Impact","keywords":["ransomware","cifratura","file cifrati","riscatto","criptati"],"mitigations":["Backup offline","Segmentazione rete","EDR anti-ransomware","Piano di incident response"]},
    "T1560": {"name":"Archive Collected Data","tactic":"Collection","keywords":["archivio","zip","rar","compressione","compressi","7z"],"mitigations":["Monitoraggio compressione massiva","DLP","Alert su archivi anomali","Controllo accessi"]},
    "T1567": {"name":"Exfiltration Over Web Service","tactic":"Exfiltration","keywords":["cloud storage","dropbox","google drive","mega","upload esterno","onedrive"],"mitigations":["CASB","DLP","Proxy monitoring","Blocco upload verso servizi non autorizzati"]},
}

GROUPS: Dict[str, List[str]] = {
    "APT29-like": ["T1566","T1204","T1059","T1071"],
    "FIN7-like": ["T1566","T1204","T1059","T1547.001","T1071"],
    "TA505-like": ["T1566","T1204","T1059","T1071","T1486"],
    "LockBit-like ransomware": ["T1021.001","T1562","T1486"],
    "Generic Data Exfiltration Actor": ["T1560","T1567","T1071"],
}

def map_techniques(description: str):
    text = description.lower().strip()
    out = []
    for tid, data in TECHNIQUES.items():
        matched = [k for k in data["keywords"] if k.lower() in text]
        if matched:
            out.append({
                "id": tid,
                "name": data["name"],
                "tactic": data["tactic"],
                "confidence": round(min(0.95, 0.55 + 0.15 * len(matched)), 2),
                "matched_keywords": matched,
                "mitigations": data["mitigations"],
            })
    return out

def score_groups(detected):
    observed = {t["id"] for t in detected}
    if not observed:
        return []
    res = []
    for name, tids in GROUPS.items():
        common = observed.intersection(set(tids))
        score = len(common) / len(observed)
        if score > 0:
            conf = "alta" if score >= .81 else "media" if score >= .61 else "medio-bassa" if score >= .31 else "bassa"
            res.append({"group": name, "score": round(score,2), "confidence": conf, "matched_techniques": sorted(common), "note":"Compatibilità TTP, non attribuzione certa."})
    return sorted(res, key=lambda x: x["score"], reverse=True)

def actions_for(detected):
    actions=set(["Preservare log e artefatti prima di ogni bonifica.", "Documentare la catena di custodia degli elementi raccolti."])
    ids={t["id"] for t in detected}
    if ids & {"T1566","T1204"}:
        actions.update(["Analizzare email, allegati, header e URL coinvolti.","Verificare altri destinatari della stessa campagna phishing."])
    if "T1059" in ids:
        actions.update(["Controllare processi figli di Office, PowerShell, cmd e script engine.","Acquisire script, comandi eseguiti e timeline endpoint."])
    if "T1547.001" in ids:
        actions.update(["Verificare chiavi Run/RunOnce e cartelle di startup.","Rimuovere persistenza solo dopo acquisizione forense."])
    if "T1071" in ids:
        actions.update(["Analizzare traffico DNS/HTTP/HTTPS verso domini esterni.","Bloccare domini, IP e URL confermati come malevoli."])
    if "T1486" in ids:
        actions.update(["Isolare immediatamente gli host cifrati o sospetti.","Verificare integrità e disponibilità dei backup."])
    if ids & {"T1560","T1567"}:
        actions.update(["Verificare archivi compressi creati di recente.","Analizzare upload verso servizi cloud esterni."])
    return sorted(actions)

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    detected = map_techniques(req.description)
    return {
        "input": req.description,
        "detected_techniques": detected,
        "probable_groups": score_groups(detected),
        "operational_actions": actions_for(detected),
        "warning":"Attribuzione solo probabilistica: validare con IOC, malware, infrastruttura, vittimologia e fonti CTI."
    }

@app.get("/health")
def health():
    return {"status":"ok"}

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")
