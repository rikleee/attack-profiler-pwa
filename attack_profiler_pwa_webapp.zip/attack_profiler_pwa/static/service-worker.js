const CACHE='attack-profiler-v1';
const ASSETS=['/','/static/index.html','/static/manifest.json','/static/icons/icon-192.png','/static/icons/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)))});
self.addEventListener('fetch',e=>{ if(e.request.method!=='GET') return; e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))) });
